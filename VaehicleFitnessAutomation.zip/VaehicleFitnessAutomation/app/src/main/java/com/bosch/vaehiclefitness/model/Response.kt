package com.bosch.vaehiclefitness.model

class Response(val success: Boolean) {
}