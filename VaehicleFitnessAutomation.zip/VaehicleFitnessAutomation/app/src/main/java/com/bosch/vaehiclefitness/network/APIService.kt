package com.bosch.vaehiclefitness.network

import okhttp3.MultipartBody
import okhttp3.ResponseBody
import retrofit2.Call
import retrofit2.http.*

interface APIService {

    @Multipart
    @POST("/number_plate_check")
    fun verifyNumberPlate(
        @Part data: MultipartBody.Part
    ): Call<HashMap<String, String>>

    @Multipart
    @POST
    fun verifyImage(
        @Url url: String,
        @Part data: MultipartBody.Part
    ): Call<HashMap<String, String>>

    @Multipart
    @POST
    fun verifyVideo(
        @Url url: String,
        @Part data: ArrayList<MultipartBody.Part>
    ): Call<HashMap<String, String>>
}