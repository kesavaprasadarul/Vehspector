package com.bosch.vaehiclefitness.model;

public class LocationData {
    public double Latitude;
    public double Longitude;

    public LocationData(double lat, double longi) {
        Latitude = lat;
        Longitude = longi;
    }
}
