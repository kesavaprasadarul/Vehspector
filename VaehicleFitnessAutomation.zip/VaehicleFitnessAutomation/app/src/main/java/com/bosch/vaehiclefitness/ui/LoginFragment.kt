package com.bosch.vaehiclefitness.ui

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.appcompat.app.AlertDialog
import androidx.lifecycle.ViewModelProvider
import com.bosch.vaehiclefitness.BuildConfig
import com.bosch.vaehiclefitness.R
import com.bosch.vaehiclefitness.util.Constants.Companion.DEMO_EMAIL_ID
import com.bosch.vaehiclefitness.util.Constants.Companion.DEMO_PASSWORD
import com.bosch.vaehiclefitness.util.Constants.Companion.DEMO_UNIQUE_ID
import com.bosch.vaehiclefitness.util.Constants.Companion.DEMO_USER_ID
import kotlinx.android.synthetic.main.fragment_login.*

class LoginFragment : BaseFragment() {

    companion object {
        private val demoVehicleNumber = arrayListOf("KL13AJ6562", "KL55L2323")
        private val demoChassisNumber = arrayListOf("MA3FSEB1S00376978", "MJ4LIOG1M00984785")
    }

    private lateinit var mainViewModel: MainViewModel

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        mainViewModel = ViewModelProvider(requireActivity()).get(MainViewModel::class.java)
        return inflater.inflate(R.layout.fragment_login, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
//        if (BuildConfig.DEBUG) {
            etUniqueId.setText(DEMO_UNIQUE_ID)
            etUserId.setText(DEMO_USER_ID)
            etpassword.setText(DEMO_PASSWORD)
//        }
        btnLogIn?.setOnClickListener {
            validateCredentials(etUniqueId?.text, etUserId?.text, etpassword?.text)
        }
        getMainActivity()?.setupToolbar(R.string.title_log_in)
    }

    private fun validateCredentials(
        uniqueId: CharSequence?,
        userId: CharSequence?,
        password: CharSequence?
    ) {
        if (DEMO_UNIQUE_ID == uniqueId?.toString() && DEMO_USER_ID == userId?.toString()
            && DEMO_PASSWORD == password?.toString()
        ) {
            showVehicleDetails()
        } else {
            showToast(R.string.error_invalid_credentials)
        }
    }

    private fun showVehicleDetails() {
        var vehicleSelected = false
        val entries = arrayOf(
            getString(
                R.string.description_vehicle_details,
                demoVehicleNumber[0],
                demoChassisNumber[0]
            ),
            getString(
                R.string.description_vehicle_details,
                demoVehicleNumber[1],
                demoChassisNumber[1]
            )
        )
        AlertDialog.Builder(activity ?: return)
            .setTitle(R.string.title_choose_vehicle)
            .setSingleChoiceItems(entries, -1) { _, which ->
                mainViewModel.setVehicleDetails(
                    demoVehicleNumber[which],
                    demoChassisNumber[which],
                    DEMO_EMAIL_ID
                )
                vehicleSelected = true
            }
            .setNegativeButton(R.string.cancel, null)
            .setPositiveButton(R.string.btn_text_continue) { _, _ ->
                if (!vehicleSelected) {
                    showToast(R.string.error_no_vehicle_selected)
                } else {
                    getMainActivity()?.addFragment(
                        VehicleFitnessTestFragment(),
                        clearBackStack = true
                    )
                }
            }
            .show()
    }

}