package com.bosch.vaehiclefitness.model

data class VehicleFitness(val vehicleNumber: String, val chassisNumber: String, val emailId: String) {
    var testSteps: ArrayList<TestStep>? = null
}