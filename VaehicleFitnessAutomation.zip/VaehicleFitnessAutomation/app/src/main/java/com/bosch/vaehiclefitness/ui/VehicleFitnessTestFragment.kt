package com.bosch.vaehiclefitness.ui

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.database.Cursor
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.lifecycle.ViewModelProvider
import com.bosch.vaehiclefitness.R
import com.bosch.vaehiclefitness.model.AudioTestStep
import com.bosch.vaehiclefitness.model.ImageTestStep
import com.bosch.vaehiclefitness.model.TestStep
import com.bosch.vaehiclefitness.model.TestStep.Companion.TYPE_DRIVE_TEST
import com.bosch.vaehiclefitness.model.TestStep.Companion.TYPE_OBD_TEST
import com.bosch.vaehiclefitness.model.TestStep.Companion.TYPE_PICK_AUDIO
import com.bosch.vaehiclefitness.model.TestStep.Companion.TYPE_PICK_IMAGE
import com.bosch.vaehiclefitness.model.TestStep.Companion.TYPE_PICK_VIDEO
import com.bosch.vaehiclefitness.model.TestStep.Companion.TYPE_TEST_COMPLETED
import com.bosch.vaehiclefitness.model.TestStep.Companion.TYPE_TEST_MANUAL
import com.bosch.vaehiclefitness.model.VideoTestStep
import com.bosch.vaehiclefitness.ui.AudioRecorderDialog.Companion.KEY_AUDIO_FILE_PATH
import com.bosch.vaehiclefitness.util.Constants
import com.bosch.vaehiclefitness.util.Constants.Companion.KEY_RESULT
import kotlinx.android.synthetic.main.fragment_vehicle_fitness_test.*
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.io.OutputStream
import java.util.concurrent.TimeUnit


class VehicleFitnessTestFragment : BaseFragment(), TestStepAdapter.OnItemClickListener {

    companion object {
        private const val REQUEST_CODE_IMAGE_GALLERY = 3000
        private const val REQUEST_CODE_IMAGE_CAMERA = 3001
        private const val REQUEST_CODE_VIDEO_CAMERA = 3003
        private const val REQUEST_CODE_VIDEO_GALLERY = 3004
        private const val REQUEST_CODE_AUDIO = 3005

        private const val REQUEST_CODE_PERMISSIONS = 7000
        private val permissions = arrayOf(
            Manifest.permission.RECORD_AUDIO,
            Manifest.permission.WRITE_EXTERNAL_STORAGE,
            Manifest.permission.READ_EXTERNAL_STORAGE,
            Manifest.permission.ACCESS_FINE_LOCATION
        )
    }

    private var currentStepPosition: Int = 0
    private lateinit var testSteps: ArrayList<TestStep>
    private lateinit var testStepAdapter: TestStepAdapter
    private lateinit var mainViewModel: MainViewModel

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        mainViewModel = ViewModelProvider(requireActivity()).get(MainViewModel::class.java)
        initSteps()
        return inflater.inflate(R.layout.fragment_vehicle_fitness_test, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        testStepAdapter = TestStepAdapter(this)
        stepsRecyclerView.adapter = testStepAdapter
        testStepAdapter.submitList(testSteps)
        getMainActivity()?.setupToolbar(R.string.title_vehicle_fitness_test)
        requestPermissions(permissions, REQUEST_CODE_PERMISSIONS)
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        var permissionsAccepted = true
        when (requestCode) {
            REQUEST_CODE_PERMISSIONS -> {
                for (granted in grantResults) {
                    if (granted != PackageManager.PERMISSION_GRANTED) {
                        permissionsAccepted = false
                        break
                    }
                }
            }
        }
        if (!permissionsAccepted) {
            showToast("Please grant required permissions.")
            parentFragmentManager.popBackStack()
        }
    }

    private fun initSteps() {
        testSteps = arrayListOf(
            ImageTestStep(R.string.number_plate).apply {
                url = "/number_plate_check"; responseKey = "number_plate_status"
            },
            ImageTestStep(R.string.chassis_number).apply {
                url = "/chassis_check"; responseKey = "chassis_number_check"
            },
            ImageTestStep(R.string.pollution_cert).apply {
                url = "/poll_cert_check"; responseKey = "pollution_certificate_check"
            },
            ImageTestStep(R.string.vehicle_front_image).apply {
                url = "/ext_body_check"; responseKey = "result"
            },
            ImageTestStep(R.string.vehicle_front_right_corner_image).apply {
                url = "/ext_body_check"; responseKey = "result"
            },
            ImageTestStep(R.string.vehicle_front_left_corner_image).apply {
                url = "/ext_body_check"; responseKey = "result"
            },
            ImageTestStep(R.string.vehicle_left_image).apply {
                url = "/ext_body_check"; responseKey = "result"
            },
            ImageTestStep(R.string.vehicle_right_image).apply {
                url = "/ext_body_check"; responseKey = "result"
            },
            ImageTestStep(R.string.vehicle_back_image).apply {
                url = "/ext_body_check"; responseKey = "result"
            },
            ImageTestStep(R.string.vehicle_back_right_corner_image).apply {
                url = "/ext_body_check"; responseKey = "result"
            },
            ImageTestStep(R.string.vehicle_back_left_corner_image).apply {
                url = "/ext_body_check"; responseKey = "result"
            },
            ImageTestStep(R.string.vehicle_front_right_tyre).apply {
                url = "/tyre_check"; responseKey = "tyre_status"
            },
            ImageTestStep(R.string.vehicle_front_left_tyre).apply {
                url = "/tyre_check"; responseKey = "tyre_status"
            },
            ImageTestStep(R.string.vehicle_back_right_tyre).apply {
                url = "/tyre_check"; responseKey = "tyre_status"
            },
            ImageTestStep(R.string.vehicle_back_left_tyre).apply {
                url = "/tyre_check"; responseKey = "tyre_status"
            },
            ImageTestStep(R.string.vehicle_engine_bay).apply {
                url = "/eng_bay_check"; responseKey = "eng_bay_status"
            },
            VideoTestStep(R.string.head_lamp),
            VideoTestStep(R.string.wiper).apply {
                url = "/wiper_check"; responseKey = "wiper_status"
            },
            VideoTestStep(R.string.indicators),
            VideoTestStep(R.string.break_light),
            AudioTestStep(R.string.engine_start),
            AudioTestStep(R.string.engine_idling),
            TestStep(TYPE_OBD_TEST, R.string.obd_test),
            TestStep(TYPE_DRIVE_TEST, R.string.drive_test),
            TestStep(TYPE_TEST_COMPLETED, R.string.test_completed)
        )
    }

    override fun onItemClicked(testStep: TestStep, position: Int) {
        currentStepPosition = position
        when (testStep.type) {
            TYPE_PICK_IMAGE -> AlertDialog.Builder(activity)
                .setTitle(R.string.choose_image)
                .setItems(resources.getStringArray(R.array.array_pick_image)) { _, index ->
                    if (index == 0) { //Gallery
                        pickImageFromGallery()
                    } else { //Camera
                        dispatchTakePictureIntent()
                    }
                }
                .setCancelable(false)
                .setNegativeButton(R.string.cancel, null)
                .show()
            TYPE_PICK_VIDEO -> AlertDialog.Builder(activity)
                .setTitle(R.string.choose_video)
                .setItems(resources.getStringArray(R.array.array_pick_image)) { _, index ->
                    if (index == 0) { //Gallery
                        pickVideoFromGallery()
                    } else { //Camera
                        dispatchTakeVideoIntent()
                    }
                }
                .setCancelable(false)
                .setNegativeButton(R.string.cancel, null)
                .show()
            TYPE_PICK_AUDIO -> {
                val audioRecorderDialog = AudioRecorderDialog()
                audioRecorderDialog.setTargetFragment(this, REQUEST_CODE_AUDIO)
                audioRecorderDialog.show(parentFragmentManager, null)
            }
        }
    }

    override fun onVerifyClicked(testStep: TestStep, position: Int) {
        currentStepPosition = position
        when (testStep.type) {
            TYPE_PICK_IMAGE -> {
                if (testStep.titleResId == R.string.number_plate) {
                    verifyNumberPlate(testStep)
                } else if (testStep.titleResId == R.string.chassis_number) {
                    verifyChassisNumber(testStep)
                } else {
                    verifyImage(testStep)
                }
            }
            TYPE_PICK_VIDEO -> verifyVideo(testStep)
            TYPE_PICK_AUDIO -> verifyAudio(testStep)
            TYPE_OBD_TEST -> startActivityForResult(
                Intent(activity, OBDTestActivity::class.java), TYPE_OBD_TEST
            )
            TYPE_DRIVE_TEST -> startActivityForResult(
                Intent(activity, VehicleDriveTestActivity::class.java), TYPE_DRIVE_TEST
            )
            TYPE_TEST_COMPLETED -> {
                mainViewModel.vehicleFitness.testSteps = testSteps
                getMainActivity()?.addFragment(
                    ReportFragment(),
                    addToBackStack = false,
                    clearBackStack = true
                )
            }
            TYPE_TEST_MANUAL -> {
                gotoNextStep(testStep.status) //Already updated from the adapter
            }
        }
    }

    private fun gotoNextStep(isCurrentStepSuccess: Boolean?) {
        if (isCurrentStepSuccess != null) {
            testSteps[currentStepPosition].apply {
                status = isCurrentStepSuccess
            }
            testStepAdapter.expandNextStep()
        } else {
            showToast(R.string.something_wrong)
        }
        hideProgress()
    }

    private fun verifyImage(testStep: TestStep) {
        if (testStep is ImageTestStep && testStep.bitMap != null) {
            if (testStep.url.isNullOrBlank()) {
                showToast("API not available!")
                return
            }
            showProgress()
            mainViewModel.verifyImage(testStep).observe(this, {
                gotoNextStep(it)
            })
        } else {
            showToast(R.string.info_choose_image_to_verify)
        }
    }

    private fun verifyVideo(testStep: TestStep) {
        if (testStep is VideoTestStep && testStep.videoFrames != null) {
            if (testStep.url.isNullOrBlank()) {
                showToast("API not available!")
                return
            }
            showProgress()
            mainViewModel.verifyVideo(testStep).observe(this, {
                gotoNextStep(it)
            })
        } else {
            showToast(R.string.info_choose_video_to_verify)
        }
    }

    private fun verifyAudio(testStep: TestStep) {
        if (testStep is AudioTestStep && testStep.audioFilePath != null) {
            if (testStep.url.isNullOrBlank()) {
                showToast("API not available!")
                return
            }
            //TODO API integration
        } else {
            showToast(R.string.info_choose_audio_to_verify)
        }
    }

    private fun verifyNumberPlate(testStep: TestStep) {
        if (testStep is ImageTestStep && testStep.bitMap != null) {
            showProgress()
            mainViewModel.verifyNumberPlate(testStep).observe(this, {
                gotoNextStep(it?.toUpperCase()?.equals(mainViewModel.vehicleFitness.vehicleNumber))
            })
        } else {
            showToast(R.string.info_choose_image_to_verify)
        }
    }

    private fun verifyChassisNumber(testStep: TestStep) {
        if (testStep is ImageTestStep && testStep.bitMap != null) {
            showProgress()
            mainViewModel.verifyChassisNumber(testStep).observe(this, {
                gotoNextStep(it?.toUpperCase()?.equals(mainViewModel.vehicleFitness.chassisNumber))
            })
        } else {
            showToast(R.string.info_choose_image_to_verify)
        }
    }

    private fun pickImageFromGallery() {
        val galleryIntent = Intent()
        galleryIntent.type = "image/jpeg"
        galleryIntent.action = Intent.ACTION_GET_CONTENT
        if (galleryIntent.resolveActivity(activity?.packageManager ?: return) != null) {
            startActivityForResult(
                Intent.createChooser(galleryIntent, "Choose image..."), REQUEST_CODE_IMAGE_GALLERY
            )
        } else {
            showToast("No applications available in your device to browse images.")
        }
    }

    private fun dispatchTakePictureIntent() {
        val takePictureIntent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
        if (takePictureIntent.resolveActivity(activity?.packageManager ?: return) != null) {
            startActivityForResult(takePictureIntent, REQUEST_CODE_IMAGE_CAMERA)
        } else {
            showToast("No applications available in your device to take picture.")
        }
    }

    private fun pickVideoFromGallery() {
        val intent = Intent()
        intent.type = "video/*"
        intent.action = Intent.ACTION_PICK
        startActivityForResult(
            Intent.createChooser(intent, "Select Video"),
            REQUEST_CODE_VIDEO_GALLERY
        )
    }

    private fun dispatchTakeVideoIntent() {
        val takeVideoIntent = Intent(MediaStore.ACTION_VIDEO_CAPTURE)
        if (takeVideoIntent.resolveActivity(activity?.packageManager ?: return) != null) {
            startActivityForResult(takeVideoIntent, REQUEST_CODE_VIDEO_CAMERA)
        } else {
            showToast("No applications available in your device to take video.")
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        if (resultCode == Activity.RESULT_OK) {
            when (requestCode) {
                REQUEST_CODE_IMAGE_GALLERY, REQUEST_CODE_IMAGE_CAMERA -> {
                    try {
                        var selectedBitmap: Bitmap? = null
                        if (requestCode == REQUEST_CODE_IMAGE_GALLERY) {
                            val selectedImgUri = data?.data
                            if (null != selectedImgUri) {
                                //Storing the selected bitmap
                                selectedBitmap = BitmapFactory.decodeStream(
                                    activity?.contentResolver?.openInputStream(selectedImgUri)
                                )
                            }
                        } else {
                            selectedBitmap = data?.extras?.get("data") as? Bitmap
                        }
                        if (selectedBitmap != null) {
                            /*val targetImageView = getImageViewByRequestCode(requestCode)
                            //Setting the selected image in UI
                            val imageWidth = selectedBitmap.width
                            val imageHeight = selectedBitmap.height
                            val newWidth =
                                targetImageView?.width
                                    ?: 0 //this method should return the width of device screen.
                            val scaleFactor = newWidth.toFloat() / imageWidth.toFloat()
                            val newHeight = (imageHeight * scaleFactor).toInt()
                            val resizedBitmap = Bitmap.createScaledBitmap(
                                selectedBitmap,
                                newWidth,
                                newHeight,
                                true
                            )
                            targetImageView?.setImageBitmap(resizedBitmap)
                            selectedBitmaps[requestCode] = resizedBitmap*/
                            (testSteps[currentStepPosition] as ImageTestStep).bitMap =
                                selectedBitmap
                            testStepAdapter.notifyItemChanged(currentStepPosition)
                            return
                        }
                        showToast(R.string.something_wrong)
                    } catch (e: Exception) {
                        Log.e(Constants.TAG, "Exception in onActivityResult " + e.message)
                        showToast(R.string.something_wrong)
                    } catch (e: OutOfMemoryError) {
                        showToast(R.string.large_image_error_msg)
                        return
                    }
                }
                REQUEST_CODE_VIDEO_GALLERY, REQUEST_CODE_VIDEO_CAMERA -> onVideoCaptured(data?.data)
                REQUEST_CODE_AUDIO -> onAudioRecorded(
                    data?.getStringExtra(KEY_AUDIO_FILE_PATH) ?: return
                )
                TYPE_DRIVE_TEST -> onDriveTestResultReceived(data?.getIntExtra(KEY_RESULT, 0))
                TYPE_OBD_TEST -> onOBDResultReceived(data?.getIntExtra(KEY_RESULT, 0))
                else -> super.onActivityResult(requestCode, resultCode, data)
            }
        }
    }

    private fun onOBDResultReceived(result: Int?) {
        gotoNextStep(result == 1)
    }

    private fun onDriveTestResultReceived(result: Int?) {
        gotoNextStep(result == 1)
    }

    private fun onAudioRecorded(audioFilePath: String) {
        if (File(audioFilePath).exists()) {
            (testSteps[currentStepPosition] as AudioTestStep).audioFilePath = audioFilePath
            testStepAdapter.notifyItemChanged(currentStepPosition)
        }
    }

    private fun onVideoCaptured(videoUri: Uri?) {
        showProgress()
        val frames = splitFrames(getRealPathFromURI(videoUri))
        if (frames == null) {
            showToast(R.string.error_frame_extraction_failed)
        } else if (frames.isEmpty()) {
            showToast("Video duration cannot be more than 20 sec.")
        } else {
            (testSteps[currentStepPosition] as VideoTestStep).videoFrames = frames
            testStepAdapter.notifyItemChanged(currentStepPosition)
        }
        hideProgress()
    }

    private fun getRealPathFromURI(contentUri: Uri?): String? {
        var cursor: Cursor? = null
        val proj = arrayOf(MediaStore.Images.Media.DATA)
        cursor = activity?.managedQuery(contentUri, proj, null, null, null)
        val columnIndex = cursor?.getColumnIndexOrThrow(MediaStore.Images.Media.DATA)
        cursor?.moveToFirst()
        val path = cursor?.getString(columnIndex!!)
        return path
    }

    private fun splitFrames(actPath: String?): ArrayList<File>? {
        try {
            val retriever = MediaMetadataRetriever()
            try {
                retriever.setDataSource(actPath)
            } catch (e: java.lang.Exception) {
                e.printStackTrace()
            }
            val frameList: ArrayList<Bitmap> = ArrayList()
            val files: ArrayList<File> = ArrayList()
            val duration: String =
                retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)
                    ?: return null
            val durationMillisec = duration.toInt() //duration in millisec
            if (durationMillisec > TimeUnit.SECONDS.toMillis(15)) {
                return arrayListOf()
            }
            val durationSecond = durationMillisec / 1000 //millisec to sec.
            val framesPerSecond = 2 //no. of frames want to retrieve per second
            val numberOfFramesCaptured = framesPerSecond * durationSecond
            var count = 0
            for (i in 0 until numberOfFramesCaptured) {
                //setting time position at which you want to retrieve frames
                val currentBMP = retriever.getFrameAtTime(5000 * i.toLong())
                frameList.add(currentBMP)
                var outStream: OutputStream? = null
                val outputDir: File = activity?.cacheDir!! // context being the Activity pointer
                try {
                    val outFile = File.createTempFile("frame$count", ".jpg", outputDir)
                    count++
                    outStream = FileOutputStream(outFile)
                    currentBMP.compress(Bitmap.CompressFormat.JPEG, 100, outStream)
                    outStream.close()
                    files.add(outFile)
                } catch (e: IOException) {
                    e.printStackTrace()
                }
            }
            return files
        } catch (e: Exception) {
            e.printStackTrace()
            return null
        }
    }

}